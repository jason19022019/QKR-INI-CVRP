"""Smoke test: the pipeline should run end-to-end on the bundled tiny
example instance without raising, for at least one clustering method.

This is deliberately not a correctness/regression test (route distances
are stochastic across pennylane/QAOA versions and are not asserted here)
-- it only guards against import/wiring breakage.
"""
import os
import sys

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from qkr_ini.data import VRPLoader
from qkr_ini.feature_maps import compute_kernel_matrix
from qkr_ini.quantum_clustering import quantum_kernel_kmeans
from qkr_ini.repair import qkr_ini_repair
from qkr_ini.routing import total_route_distance

EXAMPLE = os.path.join(os.path.dirname(__file__), "..", "examples", "tiny-example.vrp")


def test_pipeline_smoke():
    vrp = VRPLoader(EXAMPLE)
    customer_coords = vrp.nodes[1:, :2]
    customer_demands = vrp.nodes[1:, 2]
    customer_ids = list(range(2, 2 + len(customer_coords)))
    capacity = vrp.capacity
    n_clusters = int(np.ceil(np.sum(customer_demands) / capacity))

    norm_data = (customer_coords - customer_coords.mean(axis=0)) / customer_coords.std(axis=0)
    K = compute_kernel_matrix(norm_data, "Angle", large_threshold=100, n_landmarks=60, seed=42)
    labels = quantum_kernel_kmeans(K, n_clusters, max_iters=50, random_state=42, track_history=False)

    clusters = [np.where(labels == k)[0].tolist() for k in range(n_clusters)]
    repaired, calls, _ = qkr_ini_repair(clusters, customer_coords, customer_demands, capacity, seed=42)

    for mem in repaired:
        assert np.sum(customer_demands[mem]) <= capacity + 1e-6

    dist = total_route_distance(repaired, customer_ids, vrp.nodes, time_limit_seconds=1)
    assert dist > 0


if __name__ == "__main__":
    test_pipeline_smoke()
    print("Smoke test passed.")
